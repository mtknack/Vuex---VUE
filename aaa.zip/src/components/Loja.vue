<template>
    <Painel titulo="Loja Virtual" verde>
        <div class="loja">
            <span>Adicionar</span>
            <input type="number" v-model.number="quantidade">
            <span>itens de <strong>R$</strong></span>
            <input type="number" v-model.number="preco">
            <button @click="adicionar">Agora!</button>
        </div>
    </Painel>
</template>

<script>
// import { mapMutations } from 'vuex'
import { mapActions } from 'vuex'

export default {
    data() {
        return {
            sequencia: 1,
            // quantidade: 1,
            // preco: 9.99,
        }
    },
    methods: {
        // ...mapMutations(['adicionarProdutos']),
        ...mapActions(['adicionarProdutos']),
        adicionar() {
            const produto = {
                id: this.sequencia,
                nome: `Produto ${this.sequencia}`,
                quantidade: this.quantidade,
                preco: this.preco
            }
            this.sequencia++

            // this.$store.state.produtos.push(produto)
            // this.$store.commit('adicionarProdutos', produto)
            // this.adicionarProdutos(produto)
            this.$store.dispatch('adicionarProdutos', produto)
        }
    },
    // v-model
    computed:{
        quantidade(){
            return this.$store.state.quantidade
        },
        preco(){
            return this.$store.state.preco
        }
    }
}
</script>

<style>
    .loja {
        display: flex;
        justify-content: center;
    }

    .loja > * {
        margin: 0px 10px;
    }

    input {
        font-size: 2rem;
        width: 90px;
    }
</style>
